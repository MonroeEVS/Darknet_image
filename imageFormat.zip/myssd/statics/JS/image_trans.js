var imgapp = angular.module('imgapp', []);

imgapp.controller('imgCtrl', function($scope, $http) {
    $scope.total = 56
    $scope.oriImage = '../../statics/image/1.PNG'
    $scope.result1 = '../../statics/image/2.PNG'
    $scope.result2 = '../../statics/image/3.PNG'

    $scope.detect = function(){
        img = document.getElementsByClassName('del')[0].getElementsByTagName('img')
    };
});
