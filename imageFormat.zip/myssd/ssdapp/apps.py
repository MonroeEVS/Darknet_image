from django.apps import AppConfig


class SsdappConfig(AppConfig):
    name = 'ssdapp'
