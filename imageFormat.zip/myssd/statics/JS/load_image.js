$('.fileinput').change(function() {
            var file = this.files[0];
            readFile(file, $(this).parent().siblings(".on"));
        });
        $(".on").mouseover(function () {
             $(this).children(".show").show();
             $(this).children(".del").show();
        });
        $(".on").mouseleave(function () {
             $(this).children(".show").hide();
             $(this).children(".del").hide();
        });
        $(".del").click(function () {
             $(this).next().remove();
             $(".show").hide();
             $(".del").hide();
             $(this).parent().hide();
             $(this).parent().siblings(".input_img").show();
             $(this).parent().siblings(".input_img").children().val("");
        });
        var on =document.querySelector(".on");
        // 需要把阅读的文件传进来file element是把读取到的内容放入的容器
        function readFile(file, element) {
            // 新建阅读器
            var reader = new FileReader();
            // 根据文件类型选择阅读方式
            switch (file.type){
                case 'image/jpg':
                case 'image/png':
                case 'image/jpeg':
                case 'image/gif':
                reader.readAsDataURL(file);
                break;
            }
            // 当文件阅读结束后执行的方法
            reader.addEventListener('load',function () {
                // 如果说让读取的文件显示的话 还是需要通过文件的类型创建不同的标签
                switch (file.type){
                    case 'image/jpg':
                    case 'image/png':
                    case 'image/jpeg':
                    case 'image/gif':
                    var img = document.createElement('img');
                    img.src = reader.result;
                    element.append(img);
                    element.siblings(".input_img").hide();
                    element.show();
                    break;
                }
            });
        }